import pandas as pd
import sqlite3

location = 'buddymove_holidayiq.csv'
df = pd.read_csv(location)
print(df.head())
