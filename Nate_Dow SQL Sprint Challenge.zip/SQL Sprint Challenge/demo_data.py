import sqlite3

# Open a connection to a new (blank) database file `demo_data.sqlite3`
connection = sqlite3.connect('demo_data.sqlite3')

curs = connection.cursor()
print("CURSOR: ", curs)

# Make a cursor, and execute an appropriate `CREATE TABLE` statement to accept
# the above data (name the table `demo`)
query = """CREATE TABLE IF NOT EXISTS demo (
        s varchar(255), 
        x int, 
        y int
        );
        """
curs.execute(query)
print("query executed")


# Write and execute appropriate `INSERT INTO` statements to add the data (as
# shown above) to the database
query = """INSERT INTO demo (s, x, y)
            VALUES ('g', 3, 9);
        """
curs.execute(query)
print("query executed")

query = """INSERT INTO demo (s, x, y)
            VALUES ('v', 5, 7);
        """
curs.execute(query)
print("query executed")

query = """INSERT INTO demo (s, x, y)
            VALUES ('f', 8, 7);
        """
curs.execute(query)
print("query executed")

# Make sure to `commit()` so your data is saved! The file size should be non-zero.
connection.commit()

# Count how many rows you have - it should be 3!
query = """SELECT count(s)
            FROM demo
        """
total_rows = curs.execute(query).fetchall()
print("Total rows: ", total_rows)

# - How many rows are there where both `x` and `y` are at least 5?
query = """SELECT count(x) as 'x & y >= 5'
            FROM demo
            WHERE x >= 5 AND y >=5
        """
total_rows = curs.execute(query).fetchall()
print("Total rows where both x and y are at least 5: ", total_rows)

# - How many unique values of `y` are there (hint - `COUNT()` can accept a keyword
#  `DISTINCT`)? 
query = """SELECT count(DISTINCT y) as 'Distinct y vals'
            FROM demo
        """
y_values = curs.execute(query).fetchall()
print("Distinct 'y' Values: ", y_values)


"""
OUTPUT:
Total rows:  [(3,)]
Total rows where both x and y are at least 5:  [(2,)]
Distinct 'y' Values:  [(2,)]
"""

connection.close()
