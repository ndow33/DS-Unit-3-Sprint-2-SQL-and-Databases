import sqlite3

"""
### Part 2 - The Northwind Database

Using `sqlite3`, connect to the given `northwind_small.sqlite3` database.

Answer the following questions (each is from a single table):

- 
- .)
"""
# Open a connection to northwind.sqlite3
connection = sqlite3.connect('northwind_small.sqlite3')

curs = connection.cursor()
print("Cursor created")
print('-------------------------------------------------------')

# What are the ten most expensive items (per unit price) in the database?
query = """SELECT ProductName
            FROM Product
            ORDER BY UnitPrice DESC
            LIMIT 10
        """
top_ten = curs.execute(query).fetchall()
print("Ten most expensive items by unit price: ", top_ten)
print('-------------------------------------------------------')

# What is the average age of an employee at the time of their hiring? (Hint: a
# lot of arithmetic works with dates
query = """SELECT SUM((HireDate - BirthDate))/count(Id) as avg_age 
            FROM Employee
        """
avg_age = curs.execute(query).fetchall()
print("Average age of an employee at the time of their hiring: ", avg_age)
print('-------------------------------------------------------')


# What are the ten most expensive items (per unit price) in the database *and*
# their suppliers?
query = """SELECT Product.ProductName, Supplier.CompanyName
            FROM Product
            JOIN Supplier on Product.SupplierId = Supplier.Id
            ORDER BY UnitPrice DESC
            LIMIT 10
        """
price_and_company = curs.execute(query).fetchall()
print("the ten most expensive items (per unit price) in the database and their suppliers: ", price_and_company)
print('-------------------------------------------------------')

# What is the largest category (by number of unique products in it)?

connection.commit()
connection.close()